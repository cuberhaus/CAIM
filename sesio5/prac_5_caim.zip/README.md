En dumping trobarem l'output segons la inicialització de P
a dins de cada carpeta nth, one i square trobarem outputs variant la variable dumping

En la carpeta Error trobarem outputs variant la variable error

Outputs:
- Dumping/
  - nth
  - one
  - square
- Error/

Document:
- lab5CAIM.pdf